USE SmallLog;

EXEC sp_spaceused TestTable;

USE BigLog;

EXEC sp_spaceused TestTable;


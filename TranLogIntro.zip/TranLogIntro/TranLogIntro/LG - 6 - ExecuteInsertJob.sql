USE msdb;

EXECUTE sp_start_job @job_name = 'InsertRowsToTestTables';